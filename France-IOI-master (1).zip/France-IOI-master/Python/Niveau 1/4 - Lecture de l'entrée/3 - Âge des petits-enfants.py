age_cadet = int(input())
age_aine = int(input())
différence_age = age_aine - age_cadet
print(différence_age)