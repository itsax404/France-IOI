nombre_lignes = int(input())
for loop in range(nombre_lignes):
    phrase = input()
    print(phrase[::-1])