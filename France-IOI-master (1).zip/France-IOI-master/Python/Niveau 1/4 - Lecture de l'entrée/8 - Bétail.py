total_karvas = 0

for x in range(20):
    nombre_betes = int(input())
    total_karvas += nombre_betes
print(total_karvas)