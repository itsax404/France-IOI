coté = (5*17+7*2+5+2*2)

print(coté*coté)
print(coté+coté+coté+coté)