#include <iostream>
#include "robot.h"
#define repeat(nb) for (int _loop = 1, _max = (nb); _loop <= _max; _loop++)
using namespace std;
int main()
{
    repeat (21)
    {
        haut();
        droite();
    }
    
    repeat (21)
    {
        gauche();
        bas();
    }
}

   