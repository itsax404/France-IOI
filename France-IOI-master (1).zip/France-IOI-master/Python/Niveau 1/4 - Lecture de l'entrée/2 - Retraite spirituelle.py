nombre_jour = int(input())

nombre_prières = nombre_jour * 57600

print(nombre_prières)