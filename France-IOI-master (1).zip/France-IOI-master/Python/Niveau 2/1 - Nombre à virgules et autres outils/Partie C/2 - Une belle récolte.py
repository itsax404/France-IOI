nombre_personnes = int(input())
nombre_fruits= int(input())

if nombre_fruits % nombre_personnes == 0:
   print("oui")
else:
   print("non")