superficie_arignon = int(input())
superficie_evaran = int(input())

if (superficie_arignon - 10) > superficie_evaran:
    print("La famille Arignon a un champ trop grand")
if (superficie_evaran) - 10 > superficie_arignon:
    print("La famille Evaran a un champ trop grand")