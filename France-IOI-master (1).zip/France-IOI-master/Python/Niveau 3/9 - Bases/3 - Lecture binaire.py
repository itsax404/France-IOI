import sys

nombre_binaire = sys.stdin.readline().rstrip("\n")

print(int(nombre_binaire, 2))