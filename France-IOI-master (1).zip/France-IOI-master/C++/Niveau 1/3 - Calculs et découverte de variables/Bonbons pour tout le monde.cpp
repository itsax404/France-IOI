#include <iostream>
using namespace std;

int main(){
    cout << (((25+30+27+22)-8)*3) << endl;
}