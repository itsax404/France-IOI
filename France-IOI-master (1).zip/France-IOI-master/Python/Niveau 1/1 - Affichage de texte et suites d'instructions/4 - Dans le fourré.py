from robot import *

haut()
haut()
haut()
droite()
droite()
bas()
bas()
droite()