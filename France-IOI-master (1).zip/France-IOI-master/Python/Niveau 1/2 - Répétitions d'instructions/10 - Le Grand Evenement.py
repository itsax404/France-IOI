from robot import *
for loop in range(20):

   ramasser()
   for loop in range(15):
      droite()
    
   deposer()
   
   for loop in range(15):
      gauche()