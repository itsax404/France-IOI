#include <iostream>

using namespace std;

int main(){

    int incantationParJour = 57600;
    int nombreJours;
    cin >> nombreJours;
    cout << nombreJours * incantationParJour <<endl;

}