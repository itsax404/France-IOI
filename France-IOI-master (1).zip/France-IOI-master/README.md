# France-IOI

Voici mes réponses du site [www.france-ioi.org](France-IOI) dans les langagues Python, Java et C++

Pour le langague Python, je vous **déconseille** de voir le niveau 3 (pas encore prêt). J'essaye de suivre le PEP8.

Pour le langague C++, je dois modifier l'emplacement des `{` car je les positionne comme en Java et c'est pas bon.

Enfin pour le Java et le C++, je dois renommer les fichiers avec les numéros.