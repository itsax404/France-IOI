for loop in range(20):
   for loop in range(20):
      print("OX", end = "")
   print()

   for loop in range(20):
      print("XO", end = "")
   print()