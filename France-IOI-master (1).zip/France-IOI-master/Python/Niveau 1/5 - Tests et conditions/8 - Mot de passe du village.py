mot_de_passe = int(input())

if mot_de_passe != 64741:
    print("Allez-vous en !")
else:
    print("Bon festin !")