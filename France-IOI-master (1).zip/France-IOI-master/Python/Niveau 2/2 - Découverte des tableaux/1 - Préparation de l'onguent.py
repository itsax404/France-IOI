quantité_ingrédients = [500, 180, 650, 25, 666, 42, 421, 1, 370, 211]
index_ingrédients = int(input())
print(quantité_ingrédients[index_ingrédients])