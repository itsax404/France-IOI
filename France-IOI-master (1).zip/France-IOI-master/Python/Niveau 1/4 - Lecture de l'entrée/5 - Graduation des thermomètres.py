température_min = int(input())
température_max = int(input())

for degré in range(température_in, température_max+1):
    print(degré)