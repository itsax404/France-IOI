nombre_lignes = int(input())
for x in range(nombre_lignes):
   ligne = input()
   if x % 2 == 0:
      print(ligne)