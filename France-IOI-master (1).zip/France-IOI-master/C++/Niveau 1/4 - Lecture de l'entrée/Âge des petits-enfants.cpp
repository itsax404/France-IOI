#include <iostream>
using namespace std;

int main()
{
   int ageCadet;
   int ageAine;
   cin >> ageCadet;
   cin >> ageAine;
   int difference = ageAine - ageCadet;
   cout << difference << endl;
}