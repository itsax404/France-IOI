nom_auteur1 = input()
nom_auteur2 = input()

if nom_auteur1 == nom_auteur2:
   print()
elif nom_auteur2 < nom_auteur1:
   print(nom_auteur1)
elif nom_auteur1 < nom_auteur2:
   print(nom_auteur2)