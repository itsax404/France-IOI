nombre_lieues = float(input())

nombre_kilomètres = (nombre_lieues/0.707)

print(nombre_kilomètres)