nombre_paquets = int(input())
poids_paquets = int(input())

poids_total = nombre_paquets * poids_paquets

if(poids_total > 105):
    print("Surcharge !")