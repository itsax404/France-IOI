#include <iostream>
using namespace std;

int main(){

    for(int a = 1; a <= 20; a++){
        for(int b = 1; b <= 20; b++){
            cout << (a*b) <<" ";
        }
        cout << endl;
    }
}