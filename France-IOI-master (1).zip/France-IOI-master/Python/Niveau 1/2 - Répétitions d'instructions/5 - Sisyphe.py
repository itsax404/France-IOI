from robot import *

for loop in range(21):
   haut()
   droite()
   
for loop in range(21):
   gauche()
   bas()