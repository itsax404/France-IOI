#include <iostream>
using namespace std;

int main(){

    int distanceTotale = 2+34+6;

    cout << distanceTotale << " ";
    cout << (distanceTotale*2) << " ";
    cout << (distanceTotale*3) <<endl;
}