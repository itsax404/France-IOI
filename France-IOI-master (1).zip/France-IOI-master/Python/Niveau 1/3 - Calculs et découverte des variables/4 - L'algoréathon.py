distance = 42

print(distance, end = " ")
print(distance*2, end = " ")
print(distance*3, end = " ")