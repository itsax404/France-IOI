for loop in range(135):
   print("Je dois respecter le Grand Sorcier.")