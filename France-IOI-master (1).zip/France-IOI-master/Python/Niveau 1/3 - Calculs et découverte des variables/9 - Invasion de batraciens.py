nombre_crapauds = 1337
for loop in range(12):
  nombre_crapauds = nombre_crapauds * 2
print(nombre_crapauds)