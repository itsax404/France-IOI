import algorea.Scanner;

class Main{

    static Scanner entrée = new Scanner(System.in);
    public static void main(String[] args){
        double lieues = entrée.nextDouble();
        double kilomètres = lieues / 0.707
        print(kilomètres);
    }

    private static void print(Object object){
        System.out.println(object);
    }
}
