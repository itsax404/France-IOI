#include <iostream>
using namespace std;
int main()
{
    cout << "Coucou !" << endl;
    cout << "Je m'appelle Camthalion" << endl;
    cout << "Ma devise est 'Parler peu mais parler bien'." << endl;
   
}