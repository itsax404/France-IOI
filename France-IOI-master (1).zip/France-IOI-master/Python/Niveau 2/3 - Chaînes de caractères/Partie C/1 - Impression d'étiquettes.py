phrase = input()
nombre_phrase = len(phrase)
for x in range(nombre_phrase):
   print(phrase[x])