bonbons = 0

for x in range(50):
  bonbons = bonbons + (x+1)
  print(bonbons)