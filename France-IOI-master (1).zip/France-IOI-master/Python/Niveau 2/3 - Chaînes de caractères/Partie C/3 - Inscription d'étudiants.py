prenom = input()

if prenom[0] < "G":
   print("1")
elif "F" < prenom[0] < "Q":
   print("2")
else:
   print("3")