#include <iostream>

using namespace std;

int main(){

    int nombreRepetitions;
    cin >> nombreRepetitions;
    for(int i = 1; i <= nombreRepetitions; i++){
        cout << "Je dois suivre en cours" << endl;
    }

}