#include <iostream>
using namespace std;

int main(){

    for(int _loop2 = 0; _loop2 < 30; _loop2++){
        cout << "a_";
    }

    cout << endl;

    
    for(int _loop2 = 0; _loop2 < 30; _loop2++){
        cout << "b_";
    }

    cout << endl;

    
    for(int _loop2 = 0; _loop2 < 30; _loop2++){
        cout << "c_";
    }

    

}