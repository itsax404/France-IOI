ligne = 1
for x in range(20):
  colonne = 1
  for y in range(20):
    print(colonne*ligne, end = " ")
    colonne = colonne + 1
  print()
  ligne = ligne + 