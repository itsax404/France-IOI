#include <iostream>
#include "robot.h"
using namespace std;

int main(){

    haut();
    haut();
    haut();
    droite();
    droite();
    bas();
    bas();
    droite();
}