somme = 0

for x in range(1, 18,2):
    somme += x**3

print(somme)
