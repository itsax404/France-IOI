temps = float(input())
distance_en_metres = temps*340.29
distance_en_kilometres = distance_en_metres/1000
distance_en_kilometres = round(distance_en_kilometres)
print(distance_en_kilometres)
