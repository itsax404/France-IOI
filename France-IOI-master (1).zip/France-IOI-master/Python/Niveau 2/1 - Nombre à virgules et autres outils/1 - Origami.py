épaisseur_feuille = 0.110
for _ in range(15):
   épaisseur_feuille *= 2
print(épaisseur_feuille*(10**-4))