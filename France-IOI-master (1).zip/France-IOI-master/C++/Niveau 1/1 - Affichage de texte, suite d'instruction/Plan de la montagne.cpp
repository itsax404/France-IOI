#include <iostream>
using namespace std;

int main(){
    cout << "Tout droit tu grimperas," <<endl;
    cout << "La clé tu trouveras," <<endl;
    cout << "Habile tu seras," <<endl;
    cout << "Quand tu les porteras," <<endl;
    cout << "Et avec le chef tu reviendras !" <<endl;
}