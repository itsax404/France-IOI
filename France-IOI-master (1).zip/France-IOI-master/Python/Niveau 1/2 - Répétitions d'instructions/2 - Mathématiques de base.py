for loop in range(13):
  print("9 * 8 = 72")