longueur_champ = int(input())

recoltes = (longueur_champ*longueur_champ)*23

print(recoltes)