#include <iostream>
using namespace std;

int main(){
    int nombreLivres, argentDisponible;

    cin >> nombreLivres >> argentDisponible;

    cout << nombreLivres / argentDisponible << endl;

}