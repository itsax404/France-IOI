nombre_nombres = int(input())

nombre_depart = 66

for multiple in range(1,nombre_nombres+1):
    nombre_depart *= multiple
    print(nombre_depart)