for x in range(6):
    auteur = input()
    titre = input()
    print(titre)
    print(auteur)