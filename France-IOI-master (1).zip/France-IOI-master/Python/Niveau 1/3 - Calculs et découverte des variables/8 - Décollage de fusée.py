for x in range(100,-1,-1):
  print(x)
print("Décollage !")