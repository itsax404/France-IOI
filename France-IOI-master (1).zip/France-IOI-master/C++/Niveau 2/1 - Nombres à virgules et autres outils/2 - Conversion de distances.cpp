#include <iostream>
using namespace std;

int main(){

    double nombreKilometres = 0, nombreLieues;

    cin >> nombreLieues;

    nombreKilometres = nombreLieues/0.707;

    cout << nombreKilometres << endl;
}