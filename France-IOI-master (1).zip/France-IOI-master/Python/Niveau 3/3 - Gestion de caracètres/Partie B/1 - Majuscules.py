phrase = input()

phrase_en_majuscule = input().upper()

print(phrase_en_majuscule)