for loop in range(30):
   print("a", end = "_")
print()
for loop in range(30):
   print("b", end = "_")
print()
for loop in range(30):
   print("c", end = "_")