#include <iostream>
using namespace std;

int main(){

    cout << "V" << endl;
    cout << "V" << endl;
    cout << "I" << endl;
    cout << "I" << endl;
    cout << "V" << endl;
    cout << "I" << endl;
    cout << "I" << endl;
}