for x in range(100):
  print(x+1)
print("J'arrive !")