#include <iostream>
using namespace std;

int main(){

    for(int a = 0; a<20; a++){
        for(int b =0; b<20; b++){
            cout << "OX";
        }
        cout << endl;
        for(int b =0; b<20; b++){
            cout << "XO";
        }
        cout << endl;
    }

}