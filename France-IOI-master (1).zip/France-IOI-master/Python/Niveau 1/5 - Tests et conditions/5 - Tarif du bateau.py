âge = int(input())

if âge < 21:
    print("Tarif réduit")
else:
    print("Tarif plein")