#include <iostream>
using namespace std;

int main(){
    cout << (12581 - 11937) << endl;
}