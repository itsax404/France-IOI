#include <iostream>
using namespace std;

int main(){
    int quantiteIngredients[10] =  {500,180,650,25,666,42,421,1,370,211};

    int indexIngredient;

    cin >> indexIngredient;

    cout << quantiteIngredients[indexIngredient] << endl;

} 