argent = int(input())
prix = int(input())

print(argent//prix)