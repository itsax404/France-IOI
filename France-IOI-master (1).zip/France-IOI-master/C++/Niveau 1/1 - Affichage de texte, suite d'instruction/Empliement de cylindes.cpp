#include <iostream>
#include "robot.h"
using namespace std;

int main(){

    deplacer(1,3);
    deplacer(1,2);
    deplacer(3,2);
    deplacer(1,3);
    deplacer(2,1);
    deplacer(2,3);
    deplacer(1,3);
    deplacer(1,2);
    deplacer(3,1);
    deplacer(3,2);
    deplacer(1,2);
    deplacer(3,1);
    deplacer(2,3);
    deplacer(2,1);
    deplacer(3,1);
    deplacer(2,3);
    deplacer(1,3);
    deplacer(1,2);
    deplacer(3,2);
    deplacer(1,3);
    deplacer(2,1);
    deplacer(2,3);
    deplacer(1,3);

}