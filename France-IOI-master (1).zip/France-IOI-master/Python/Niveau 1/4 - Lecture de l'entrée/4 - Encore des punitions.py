nombre_lignes = int(input())

for _ in range(nombre_lignes):
    print("Je dois suivre en cours")
    print()